import { LessonLayout, Section, CodeBlock } from "@/components/LessonLayout";

const Modules = () => {
  return (
    <LessonLayout
      title="Модули"
      description="Модули позволяют организовать код в отдельные файлы и использовать готовые функции из стандартной библиотеки или сторонних пакетов."
    >
      <Section title="Что такое модуль?">
        <p>
          Модуль — это файл Python (.py), содержащий определения функций, классов и переменных. 
          Модули помогают структурировать код и повторно использовать функциональность.
        </p>
      </Section>

      <Section title="Импорт модулей">
        <p>
          Для использования модуля нужно его импортировать с помощью оператора 
          <code className="bg-code-bg px-2 py-1 rounded ml-1">import</code>.
        </p>
      </Section>

      <CodeBlock title="Способы импорта">
{`# Импорт всего модуля
import math
print(math.pi)  # 3.141592653589793
print(math.sqrt(16))  # 4.0

# Импорт конкретных функций
from math import sqrt, pow
print(sqrt(25))  # 5.0
print(pow(2, 3))  # 8.0

# Импорт с псевдонимом
import datetime as dt
now = dt.datetime.now()
print(now)

# Импорт всего содержимого (не рекомендуется)
from math import *
print(ceil(4.2))  # 5`}
      </CodeBlock>

      <Section title="Популярные встроенные модули">
        <p>Python имеет богатую стандартную библиотеку с множеством полезных модулей:</p>
      </Section>

      <CodeBlock title="Модуль math">
{`import math

# Математические константы
print(math.pi)  # 3.141592653589793
print(math.e)   # 2.718281828459045

# Математические функции
print(math.sqrt(16))      # 4.0
print(math.pow(2, 3))     # 8.0
print(math.ceil(4.2))     # 5
print(math.floor(4.8))    # 4
print(math.factorial(5))  # 120

# Тригонометрия
print(math.sin(math.pi / 2))  # 1.0
print(math.cos(0))             # 1.0`}
      </CodeBlock>

      <CodeBlock title="Модуль random">
{`import random

# Случайное число от 0 до 1
print(random.random())

# Случайное целое число в диапазоне
print(random.randint(1, 10))

# Случайный выбор из списка
colors = ["красный", "синий", "зеленый"]
print(random.choice(colors))

# Перемешивание списка
numbers = [1, 2, 3, 4, 5]
random.shuffle(numbers)
print(numbers)

# Случайная выборка
sample = random.sample(range(1, 50), 5)
print(sample)`}
      </CodeBlock>

      <CodeBlock title="Модуль datetime">
{`from datetime import datetime, timedelta

# Текущая дата и время
now = datetime.now()
print(f"Сейчас: {now}")

# Форматирование даты
formatted = now.strftime("%d.%m.%Y %H:%M:%S")
print(formatted)

# Создание конкретной даты
new_year = datetime(2025, 1, 1)
print(f"Новый год: {new_year}")

# Операции с датами
tomorrow = now + timedelta(days=1)
week_ago = now - timedelta(weeks=1)
print(f"Завтра: {tomorrow}")
print(f"Неделю назад: {week_ago}")`}
      </CodeBlock>

      <Section title="Создание собственного модуля">
        <p>
          Вы можете создать свой модуль, просто сохранив функции в отдельном .py файле.
        </p>
      </Section>

      <CodeBlock title="Файл mymodule.py">
{`# mymodule.py
def greeting(name):
    return f"Привет, {name}!"

def add(a, b):
    return a + b

PI = 3.14159

# Использование модуля в другом файле:
# import mymodule
# print(mymodule.greeting("Иван"))
# print(mymodule.add(5, 3))
# print(mymodule.PI)`}
      </CodeBlock>

      <Section title="Установка внешних модулей">
        <p>
          Внешние модули устанавливаются с помощью менеджера пакетов 
          <code className="bg-code-bg px-2 py-1 rounded ml-1">pip</code>.
        </p>
      </Section>

      <CodeBlock title="Работа с pip">
{`# Установка пакета
pip install requests

# Установка конкретной версии
pip install requests==2.28.0

# Обновление пакета
pip install --upgrade requests

# Удаление пакета
pip uninstall requests

# Список установленных пакетов
pip list

# Информация о пакете
pip show requests`}
      </CodeBlock>
    </LessonLayout>
  );
};

export default Modules;
