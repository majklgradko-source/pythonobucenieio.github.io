import { LessonLayout, Section, CodeBlock } from "@/components/LessonLayout";

const Strings = () => {
  return (
    <LessonLayout
      title="Строки"
      description="Строки — это последовательности символов, заключенные в кавычки. Python предоставляет множество методов для работы со строками."
    >
      <Section title="Создание строк">
        <p>
          Строки можно создавать с использованием одинарных, двойных или тройных кавычек.
        </p>
      </Section>

      <CodeBlock title="Различные способы создания строк">
{`# Одинарные кавычки
text1 = 'Привет, мир!'

# Двойные кавычки
text2 = "Python - отличный язык"

# Тройные кавычки (многострочные)
text3 = """
Это многострочная
строка в Python
"""

# Экранирование символов
quote = 'Он сказал: \\'Привет!\\''
path = "C:\\\\Users\\\\Name\\\\file.txt"

# Сырые строки (игнорируют экранирование)
raw_path = r"C:\\Users\\Name\\file.txt"`}
      </CodeBlock>

      <Section title="Операции со строками">
        <p>
          Python поддерживает различные операции для объединения и повторения строк.
        </p>
      </Section>

      <CodeBlock title="Конкатенация и повторение">
{`# Конкатенация (объединение)
first_name = "Иван"
last_name = "Петров"
full_name = first_name + " " + last_name
print(full_name)  # Иван Петров

# Повторение
line = "=" * 20
print(line)  # ====================

# Длина строки
text = "Python"
print(len(text))  # 6

# Проверка вхождения
if "Py" in text:
    print("Найдено!")

# Доступ к символам по индексу
print(text[0])   # P
print(text[-1])  # n (последний символ)`}
      </CodeBlock>

      <Section title="Срезы строк">
        <p>
          Срезы позволяют извлекать части строки.
        </p>
      </Section>

      <CodeBlock title="Работа со срезами">
{`text = "Python Programming"

# Базовые срезы
print(text[0:6])    # Python
print(text[:6])     # Python (с начала)
print(text[7:])     # Programming (до конца)
print(text[-11:])   # Programming

# Срезы с шагом
print(text[::2])    # Pto rgamn (каждый второй)
print(text[::-1])   # gnimmargorP nohtyP (реверс)

# Копирование строки
copy = text[:]`}
      </CodeBlock>

      <Section title="Методы строк">
        <p>
          Python предоставляет множество встроенных методов для работы со строками.
        </p>
      </Section>

      <CodeBlock title="Популярные методы строк">
{`text = "  Python Programming  "

# Изменение регистра
print(text.upper())       # PYTHON PROGRAMMING
print(text.lower())       # python programming
print(text.title())       # Python Programming
print(text.capitalize())  # Python programming

# Удаление пробелов
print(text.strip())   # "Python Programming"
print(text.lstrip())  # "Python Programming  "
print(text.rstrip())  # "  Python Programming"

# Поиск и замена
print(text.find("Python"))      # 2
print(text.replace("Python", "Java"))
print(text.count("m"))          # 2

# Проверки
print("123".isdigit())     # True
print("abc".isalpha())     # True
print("abc123".isalnum())  # True`}
      </CodeBlock>

      <Section title="Форматирование строк">
        <p>
          Существует несколько способов форматирования строк в Python.
        </p>
      </Section>

      <CodeBlock title="Способы форматирования">
{`name = "Анна"
age = 25
price = 99.99

# f-строки (рекомендуется)
message = f"Меня зовут {name}, мне {age} лет"
print(message)

# Выражения в f-строках
print(f"Через 5 лет мне будет {age + 5}")
print(f"Цена: {price:.2f} руб.")

# Метод format()
text = "Меня зовут {}, мне {} лет".format(name, age)
print(text)

# С именованными параметрами
text = "Меня зовут {n}, мне {a} лет".format(n=name, a=age)

# Старый способ (%)
text = "Меня зовут %s, мне %d лет" % (name, age)
print(text)`}
      </CodeBlock>

      <Section title="Разделение и объединение">
        <p>
          Методы для разделения строк на части и их объединения.
        </p>
      </Section>

      <CodeBlock title="split() и join()">
{`# Разделение строки
text = "Python,Java,JavaScript,C++"
languages = text.split(",")
print(languages)  # ['Python', 'Java', 'JavaScript', 'C++']

# Разделение по пробелам
sentence = "Это простое предложение"
words = sentence.split()
print(words)  # ['Это', 'простое', 'предложение']

# Объединение списка в строку
fruits = ["яблоко", "банан", "апельсин"]
result = ", ".join(fruits)
print(result)  # яблоко, банан, апельсин

# Объединение с переносом строки
lines = ["Первая строка", "Вторая строка", "Третья строка"]
text = "\\n".join(lines)
print(text)`}
      </CodeBlock>
    </LessonLayout>
  );
};

export default Strings;
