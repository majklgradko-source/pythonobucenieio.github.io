import { LessonLayout, Section, CodeBlock } from "@/components/LessonLayout";

const Conditions = () => {
  return (
    <LessonLayout
      title="Условия"
      description="Условные операторы позволяют выполнять различные блоки кода в зависимости от выполнения определенных условий."
    >
      <Section title="Оператор if">
        <p>
          Основной условный оператор <code className="bg-code-bg px-2 py-1 rounded">if</code> 
          выполняет код, если условие истинно.
        </p>
      </Section>

      <CodeBlock title="Простые условия">
{`# Простое условие
age = 18
if age >= 18:
    print("Вы совершеннолетний")

# Условие с else
temperature = 25
if temperature > 30:
    print("Очень жарко")
else:
    print("Температура комфортная")

# Множественные условия с elif
score = 85
if score >= 90:
    print("Отлично!")
elif score >= 75:
    print("Хорошо!")
elif score >= 60:
    print("Удовлетворительно")
else:
    print("Нужно больше учиться")`}
      </CodeBlock>

      <Section title="Операторы сравнения">
        <p>Python поддерживает следующие операторы сравнения:</p>
        <ul className="list-disc list-inside space-y-2 ml-4">
          <li><code className="bg-code-bg px-2 py-1 rounded">==</code> — равно</li>
          <li><code className="bg-code-bg px-2 py-1 rounded">!=</code> — не равно</li>
          <li><code className="bg-code-bg px-2 py-1 rounded">&gt;</code> — больше</li>
          <li><code className="bg-code-bg px-2 py-1 rounded">&lt;</code> — меньше</li>
          <li><code className="bg-code-bg px-2 py-1 rounded">&gt;=</code> — больше или равно</li>
          <li><code className="bg-code-bg px-2 py-1 rounded">&lt;=</code> — меньше или равно</li>
        </ul>
      </Section>

      <CodeBlock title="Примеры операторов сравнения">
{`# Операторы сравнения
x = 10
y = 5

print(x == y)   # False
print(x != y)   # True
print(x > y)    # True
print(x < y)    # False
print(x >= 10)  # True
print(y <= 5)   # True

# Сравнение строк
name1 = "Python"
name2 = "python"
print(name1 == name2)  # False (регистр важен)
print(name1.lower() == name2.lower())  # True`}
      </CodeBlock>

      <Section title="Логические операторы">
        <p>
          Логические операторы <code className="bg-code-bg px-2 py-1 rounded">and</code>, 
          <code className="bg-code-bg px-2 py-1 rounded ml-1">or</code> и 
          <code className="bg-code-bg px-2 py-1 rounded ml-1">not</code> позволяют 
          комбинировать условия.
        </p>
      </Section>

      <CodeBlock title="Логические операторы">
{`# Оператор and (И)
age = 25
has_license = True

if age >= 18 and has_license:
    print("Вы можете водить машину")

# Оператор or (ИЛИ)
is_weekend = True
is_holiday = False

if is_weekend or is_holiday:
    print("Можно отдыхать!")

# Оператор not (НЕ)
is_raining = False

if not is_raining:
    print("Можно пойти гулять")

# Комбинация операторов
temperature = 22
is_sunny = True

if temperature > 20 and is_sunny and not is_raining:
    print("Отличная погода для прогулки!")`}
      </CodeBlock>

      <Section title="Тернарный оператор">
        <p>
          Python поддерживает компактную форму условного выражения в одну строку.
        </p>
      </Section>

      <CodeBlock title="Тернарный оператор">
{`# Обычная форма
age = 20
if age >= 18:
    status = "взрослый"
else:
    status = "ребенок"

# Тернарная форма
age = 20
status = "взрослый" if age >= 18 else "ребенок"

# Примеры использования
x = 10
y = 20
max_value = x if x > y else y
print(f"Максимальное значение: {max_value}")

# В строках
score = 85
result = "Сдал" if score >= 60 else "Не сдал"
print(result)`}
      </CodeBlock>

      <Section title="Проверка вхождения">
        <p>
          Оператор <code className="bg-code-bg px-2 py-1 rounded">in</code> проверяет 
          наличие элемента в последовательности.
        </p>
      </Section>

      <CodeBlock title="Оператор in">
{`# Проверка в списке
fruits = ["яблоко", "банан", "апельсин"]
if "банан" in fruits:
    print("Банан есть в списке")

# Проверка в строке
text = "Python - отличный язык"
if "Python" in text:
    print("Слово найдено")

# Проверка отсутствия
if "Java" not in text:
    print("Java не упоминается")

# Проверка в словаре
user = {"имя": "Иван", "возраст": 30}
if "имя" in user:
    print(f"Имя пользователя: {user['имя']}")`}
      </CodeBlock>
    </LessonLayout>
  );
};

export default Conditions;
