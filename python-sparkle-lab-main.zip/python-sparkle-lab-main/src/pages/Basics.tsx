import { LessonLayout, Section, CodeBlock } from "@/components/LessonLayout";

const Basics = () => {
  return (
    <LessonLayout
      title="Основы Python"
      description="Изучите фундаментальные концепции Python: типы данных, операторы, ввод/вывод и базовый синтаксис языка."
    >
      <Section title="Типы данных">
        <p>В Python существует несколько основных типов данных:</p>
        <ul className="list-disc list-inside space-y-2 ml-4">
          <li><strong>int</strong> — целые числа (например: 42, -17, 0)</li>
          <li><strong>float</strong> — числа с плавающей точкой (например: 3.14, -0.001)</li>
          <li><strong>str</strong> — строки (например: "Привет", 'Python')</li>
          <li><strong>bool</strong> — логические значения (True, False)</li>
          <li><strong>list</strong> — списки (например: [1, 2, 3])</li>
          <li><strong>dict</strong> — словари (например: {`{"имя": "Иван"}`})</li>
        </ul>
      </Section>

      <CodeBlock title="Примеры типов данных">
{`# Целые числа
age = 25
count = -10

# Числа с плавающей точкой
price = 99.99
temperature = -5.5

# Строки
name = "Анна"
message = 'Добро пожаловать!'

# Логические значения
is_active = True
is_valid = False

# Списки
numbers = [1, 2, 3, 4, 5]
fruits = ["яблоко", "банан", "апельсин"]

# Словари
person = {
    "имя": "Иван",
    "возраст": 30,
    "город": "Москва"
}`}
      </CodeBlock>

      <Section title="Базовые операторы">
        <p>Python поддерживает стандартные математические и логические операторы:</p>
      </Section>

      <CodeBlock title="Арифметические операторы">
{`# Сложение
result = 10 + 5  # 15

# Вычитание
result = 10 - 5  # 5

# Умножение
result = 10 * 5  # 50

# Деление
result = 10 / 5  # 2.0

# Целочисленное деление
result = 10 // 3  # 3

# Остаток от деления
result = 10 % 3  # 1

# Возведение в степень
result = 2 ** 3  # 8`}
      </CodeBlock>

      <Section title="Ввод и вывод">
        <p>
          Функция <code className="bg-code-bg px-2 py-1 rounded">print()</code> используется для 
          вывода данных, а <code className="bg-code-bg px-2 py-1 rounded">input()</code> — для 
          получения данных от пользователя.
        </p>
      </Section>

      <CodeBlock title="Работа с вводом и выводом">
{`# Вывод текста
print("Привет, Python!")

# Вывод нескольких значений
name = "Мария"
age = 28
print("Имя:", name, "Возраст:", age)

# Форматированный вывод
print(f"Меня зовут {name}, мне {age} лет")

# Ввод данных от пользователя
user_name = input("Введите ваше имя: ")
print(f"Привет, {user_name}!")

# Преобразование типов при вводе
age = int(input("Введите ваш возраст: "))
print(f"Через 5 лет вам будет {age + 5} лет")`}
      </CodeBlock>
    </LessonLayout>
  );
};

export default Basics;
