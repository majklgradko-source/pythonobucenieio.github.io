import { LessonLayout, Section, CodeBlock } from "@/components/LessonLayout";

const Files = () => {
  return (
    <LessonLayout
      title="Работа с файлами"
      description="Python предоставляет удобные инструменты для чтения и записи файлов. Научитесь работать с текстовыми файлами, обрабатывать данные и управлять файловой системой."
    >
      <Section title="Открытие файлов">
        <p>
          Функция <code className="bg-code-bg px-2 py-1 rounded">open()</code> используется для 
          открытия файлов. Важно всегда закрывать файлы после работы с ними.
        </p>
      </Section>

      <CodeBlock title="Режимы открытия файлов">
{`# Режимы открытия:
# 'r' - чтение (по умолчанию)
# 'w' - запись (перезаписывает файл)
# 'a' - добавление в конец
# 'x' - создание нового файла
# 'b' - бинарный режим
# '+' - чтение и запись

# Открытие файла для чтения
file = open('example.txt', 'r')
content = file.read()
file.close()

# Открытие для записи
file = open('output.txt', 'w')
file.write("Привет, мир!")
file.close()

# Открытие для добавления
file = open('log.txt', 'a')
file.write("Новая запись\\n")
file.close()`}
      </CodeBlock>

      <Section title="Использование with">
        <p>
          Конструкция <code className="bg-code-bg px-2 py-1 rounded">with</code> автоматически 
          закрывает файл после завершения работы, даже если произошла ошибка.
        </p>
      </Section>

      <CodeBlock title="Безопасная работа с файлами">
{`# Чтение файла с with (рекомендуется)
with open('example.txt', 'r', encoding='utf-8') as file:
    content = file.read()
    print(content)
# Файл автоматически закрывается

# Запись в файл
with open('output.txt', 'w', encoding='utf-8') as file:
    file.write("Первая строка\\n")
    file.write("Вторая строка\\n")

# Добавление в файл
with open('log.txt', 'a', encoding='utf-8') as file:
    file.write("Новая запись в журнале\\n")`}
      </CodeBlock>

      <Section title="Чтение файлов">
        <p>
          Существует несколько способов чтения содержимого файла.
        </p>
      </Section>

      <CodeBlock title="Методы чтения">
{`# Чтение всего файла целиком
with open('example.txt', 'r', encoding='utf-8') as file:
    content = file.read()
    print(content)

# Чтение построчно в список
with open('example.txt', 'r', encoding='utf-8') as file:
    lines = file.readlines()
    for line in lines:
        print(line.strip())  # strip() удаляет \\n

# Чтение файла построчно (эффективнее для больших файлов)
with open('example.txt', 'r', encoding='utf-8') as file:
    for line in file:
        print(line.strip())

# Чтение первой строки
with open('example.txt', 'r', encoding='utf-8') as file:
    first_line = file.readline()
    print(first_line)

# Чтение определенного количества символов
with open('example.txt', 'r', encoding='utf-8') as file:
    chunk = file.read(100)  # Читает первые 100 символов`}
      </CodeBlock>

      <Section title="Запись в файлы">
        <p>
          Python позволяет записывать данные различных типов в файлы.
        </p>
      </Section>

      <CodeBlock title="Методы записи">
{`# Запись строки
with open('output.txt', 'w', encoding='utf-8') as file:
    file.write("Это первая строка\\n")
    file.write("Это вторая строка\\n")

# Запись списка строк
lines = [
    "Строка 1\\n",
    "Строка 2\\n",
    "Строка 3\\n"
]
with open('output.txt', 'w', encoding='utf-8') as file:
    file.writelines(lines)

# Запись с форматированием
name = "Иван"
age = 30
with open('user.txt', 'w', encoding='utf-8') as file:
    file.write(f"Имя: {name}\\n")
    file.write(f"Возраст: {age}\\n")

# Добавление в конец файла
with open('log.txt', 'a', encoding='utf-8') as file:
    file.write("Новая запись\\n")`}
      </CodeBlock>

      <Section title="Работа с путями">
        <p>
          Модуль <code className="bg-code-bg px-2 py-1 rounded">os</code> предоставляет 
          функции для работы с файловой системой.
        </p>
      </Section>

      <CodeBlock title="Операции с файлами и папками">
{`import os

# Проверка существования файла
if os.path.exists('example.txt'):
    print("Файл существует")

# Проверка, является ли путь файлом
if os.path.isfile('example.txt'):
    print("Это файл")

# Проверка, является ли путь папкой
if os.path.isdir('my_folder'):
    print("Это папка")

# Получение размера файла
size = os.path.getsize('example.txt')
print(f"Размер файла: {size} байт")

# Переименование файла
os.rename('old_name.txt', 'new_name.txt')

# Удаление файла
if os.path.exists('temp.txt'):
    os.remove('temp.txt')

# Создание папки
os.mkdir('new_folder')

# Создание вложенных папок
os.makedirs('folder1/folder2/folder3', exist_ok=True)

# Удаление пустой папки
os.rmdir('empty_folder')

# Список файлов в папке
files = os.listdir('.')
for file in files:
    print(file)`}
      </CodeBlock>

      <Section title="Обработка исключений">
        <p>
          При работе с файлами важно обрабатывать возможные ошибки.
        </p>
      </Section>

      <CodeBlock title="Обработка ошибок при работе с файлами">
{`# Обработка ошибок при чтении
try:
    with open('missing.txt', 'r', encoding='utf-8') as file:
        content = file.read()
except FileNotFoundError:
    print("Файл не найден!")
except PermissionError:
    print("Нет прав доступа к файлу!")
except Exception as e:
    print(f"Произошла ошибка: {e}")

# Безопасное чтение с проверкой
import os

filename = 'data.txt'
if os.path.exists(filename):
    with open(filename, 'r', encoding='utf-8') as file:
        content = file.read()
        print(content)
else:
    print("Файл не найден. Создаем новый...")
    with open(filename, 'w', encoding='utf-8') as file:
        file.write("Файл создан автоматически\\n")`}
      </CodeBlock>

      <Section title="Работа с JSON">
        <p>
          Модуль <code className="bg-code-bg px-2 py-1 rounded">json</code> позволяет 
          сохранять и загружать данные в формате JSON.
        </p>
      </Section>

      <CodeBlock title="Сохранение и загрузка JSON">
{`import json

# Запись данных в JSON
data = {
    "имя": "Иван",
    "возраст": 30,
    "хобби": ["программирование", "чтение", "спорт"]
}

with open('data.json', 'w', encoding='utf-8') as file:
    json.dump(data, file, ensure_ascii=False, indent=2)

# Чтение данных из JSON
with open('data.json', 'r', encoding='utf-8') as file:
    loaded_data = json.load(file)
    print(loaded_data)

# Преобразование в JSON строку
json_string = json.dumps(data, ensure_ascii=False, indent=2)
print(json_string)

# Парсинг JSON строки
parsed = json.loads(json_string)
print(parsed["имя"])`}
      </CodeBlock>
    </LessonLayout>
  );
};

export default Files;
