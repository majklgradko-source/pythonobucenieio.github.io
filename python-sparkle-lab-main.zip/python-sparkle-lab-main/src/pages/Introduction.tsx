import { LessonLayout, Section, CodeBlock } from "@/components/LessonLayout";
import heroImage from "@/assets/python-hero.jpg";

const Introduction = () => {
  return (
    <LessonLayout
      title="Введение в Python"
      description="Python — это высокоуровневый язык программирования общего назначения, который отличается простотой синтаксиса и читаемостью кода. Идеально подходит для начинающих программистов."
    >
      <div className="relative h-64 rounded-lg overflow-hidden mb-6">
        <img 
          src={heroImage} 
          alt="Python Programming" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-primary/80 to-primary/40 flex items-center justify-center">
          <h2 className="text-4xl font-bold text-white">Начните изучать Python</h2>
        </div>
      </div>

      <Section title="Что такое Python?">
        <p>
          Python был создан Гвидо ван Россумом и впервые выпущен в 1991 году. Название языка 
          произошло от британского комедийного шоу "Летающий цирк Монти Пайтона".
        </p>
        <p>
          Python используется в веб-разработке, анализе данных, машинном обучении, автоматизации, 
          научных вычислениях и многих других областях.
        </p>
      </Section>

      <Section title="Преимущества Python">
        <ul className="list-disc list-inside space-y-2 ml-4">
          <li>Простой и понятный синтаксис</li>
          <li>Обширная стандартная библиотека</li>
          <li>Большое сообщество разработчиков</li>
          <li>Кроссплатформенность</li>
          <li>Множество фреймворков и библиотек</li>
          <li>Подходит для быстрой разработки прототипов</li>
        </ul>
      </Section>

      <CodeBlock title="Ваша первая программа на Python">
{`# Это комментарий в Python
print("Привет, мир!")

# Переменные создаются просто
name = "Python"
version = 3.12

print(f"Язык: {name}, версия: {version}")`}
      </CodeBlock>

      <Section title="Где используется Python?">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-secondary rounded-lg">
            <h3 className="font-semibold text-primary mb-2">Веб-разработка</h3>
            <p className="text-sm">Django, Flask, FastAPI</p>
          </div>
          <div className="p-4 bg-secondary rounded-lg">
            <h3 className="font-semibold text-primary mb-2">Data Science</h3>
            <p className="text-sm">Pandas, NumPy, Matplotlib</p>
          </div>
          <div className="p-4 bg-secondary rounded-lg">
            <h3 className="font-semibold text-primary mb-2">Машинное обучение</h3>
            <p className="text-sm">TensorFlow, PyTorch, scikit-learn</p>
          </div>
          <div className="p-4 bg-secondary rounded-lg">
            <h3 className="font-semibold text-primary mb-2">Автоматизация</h3>
            <p className="text-sm">Скрипты, тестирование, DevOps</p>
          </div>
        </div>
      </Section>
    </LessonLayout>
  );
};

export default Introduction;
