import { LessonLayout, Section, CodeBlock } from "@/components/LessonLayout";

const Loops = () => {
  return (
    <LessonLayout
      title="Циклы"
      description="Циклы позволяют многократно выполнять блок кода. В Python есть два основных типа циклов: for и while."
    >
      <Section title="Цикл for">
        <p>
          Цикл <code className="bg-code-bg px-2 py-1 rounded">for</code> используется для 
          перебора элементов последовательности (списка, строки, диапазона и т.д.).
        </p>
      </Section>

      <CodeBlock title="Примеры цикла for">
{`# Перебор списка
fruits = ["яблоко", "банан", "апельсин"]
for fruit in fruits:
    print(f"Мне нравится {fruit}")

# Использование range()
for i in range(5):
    print(f"Число: {i}")  # 0, 1, 2, 3, 4

# range() с начальным и конечным значением
for i in range(2, 8):
    print(i)  # 2, 3, 4, 5, 6, 7

# range() с шагом
for i in range(0, 10, 2):
    print(i)  # 0, 2, 4, 6, 8

# Перебор строки
for letter in "Python":
    print(letter)`}
      </CodeBlock>

      <Section title="Цикл while">
        <p>
          Цикл <code className="bg-code-bg px-2 py-1 rounded">while</code> выполняется, 
          пока условие истинно.
        </p>
      </Section>

      <CodeBlock title="Примеры цикла while">
{`# Простой цикл while
count = 0
while count < 5:
    print(f"Счетчик: {count}")
    count += 1

# Бесконечный цикл с прерыванием
while True:
    answer = input("Введите 'выход' для завершения: ")
    if answer == "выход":
        break
    print(f"Вы ввели: {answer}")

# Цикл с условием
number = 1
while number <= 10:
    if number % 2 == 0:
        print(f"{number} - четное")
    number += 1`}
      </CodeBlock>

      <Section title="Управление циклами">
        <p>Операторы <code className="bg-code-bg px-2 py-1 rounded">break</code>, 
        <code className="bg-code-bg px-2 py-1 rounded ml-1">continue</code> и 
        <code className="bg-code-bg px-2 py-1 rounded ml-1">else</code> позволяют 
        управлять выполнением циклов.</p>
      </Section>

      <CodeBlock title="break, continue и else">
{`# break - прерывает цикл
for i in range(10):
    if i == 5:
        break
    print(i)  # Выведет 0, 1, 2, 3, 4

# continue - переходит к следующей итерации
for i in range(5):
    if i == 2:
        continue
    print(i)  # Выведет 0, 1, 3, 4

# else - выполняется, если цикл завершился без break
for i in range(3):
    print(i)
else:
    print("Цикл завершен")

# Пропуск нечетных чисел
for i in range(10):
    if i % 2 != 0:
        continue
    print(i)  # Выведет только четные числа`}
      </CodeBlock>

      <Section title="Вложенные циклы">
        <p>Циклы можно вкладывать друг в друга для работы с многомерными данными.</p>
      </Section>

      <CodeBlock title="Примеры вложенных циклов">
{`# Таблица умножения
for i in range(1, 6):
    for j in range(1, 6):
        print(f"{i} x {j} = {i * j}")
    print()  # Пустая строка после каждой таблицы

# Работа с двумерным списком
matrix = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
]

for row in matrix:
    for element in row:
        print(element, end=" ")
    print()  # Новая строка после каждого ряда`}
      </CodeBlock>
    </LessonLayout>
  );
};

export default Loops;
