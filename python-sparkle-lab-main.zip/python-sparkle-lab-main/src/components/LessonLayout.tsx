import { ReactNode } from "react";
import { Card } from "@/components/ui/card";

interface LessonLayoutProps {
  title: string;
  description: string;
  children: ReactNode;
}

export function LessonLayout({ title, description, children }: LessonLayoutProps) {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-4">{title}</h1>
          <p className="text-lg text-muted-foreground leading-relaxed">{description}</p>
        </div>
        
        <div className="space-y-6">
          {children}
        </div>
      </div>
    </div>
  );
}

interface CodeBlockProps {
  children: ReactNode;
  title?: string;
}

export function CodeBlock({ children, title }: CodeBlockProps) {
  return (
    <Card className="p-6 bg-code-bg border-code-border">
      {title && <h3 className="text-lg font-semibold mb-3 text-foreground">{title}</h3>}
      <pre className="bg-card p-4 rounded-lg overflow-x-auto border border-border">
        <code className="text-sm font-mono text-foreground">{children}</code>
      </pre>
    </Card>
  );
}

interface SectionProps {
  title: string;
  children: ReactNode;
}

export function Section({ title, children }: SectionProps) {
  return (
    <Card className="p-6">
      <h2 className="text-2xl font-semibold mb-4 text-foreground">{title}</h2>
      <div className="text-foreground leading-relaxed space-y-4">
        {children}
      </div>
    </Card>
  );
}
