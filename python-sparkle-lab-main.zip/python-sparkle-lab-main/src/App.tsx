import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/AppSidebar";
import Introduction from "./pages/Introduction";
import Basics from "./pages/Basics";
import Variables from "./pages/Variables";
import Loops from "./pages/Loops";
import Conditions from "./pages/Conditions";
import Modules from "./pages/Modules";
import Strings from "./pages/Strings";
import Files from "./pages/Files";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <SidebarProvider>
          <div className="flex min-h-screen w-full">
            <AppSidebar />
            <div className="flex-1 flex flex-col">
              <header className="sticky top-0 z-10 h-14 border-b bg-background flex items-center px-4">
                <SidebarTrigger />
                <h1 className="ml-4 text-lg font-semibold text-primary">Обучение Python</h1>
              </header>
              <main className="flex-1">
                <Routes>
                  <Route path="/" element={<Introduction />} />
                  <Route path="/basics" element={<Basics />} />
                  <Route path="/variables" element={<Variables />} />
                  <Route path="/loops" element={<Loops />} />
                  <Route path="/conditions" element={<Conditions />} />
                  <Route path="/modules" element={<Modules />} />
                  <Route path="/strings" element={<Strings />} />
                  <Route path="/files" element={<Files />} />
                  {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
                  <Route path="*" element={<NotFound />} />
                </Routes>
              </main>
            </div>
          </div>
        </SidebarProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
